import os, sys, threading

def trim_memory():
    """Trigger Python garbage collection explicitly on memory trim (Android TV only)."""
    if os.environ.get("NEKORIMBA_IS_TV") == "1":
        try:
            import gc
            gc.collect()
        except Exception:
            pass

def start_server(data_dir=None, is_tv=False):
    """Jalankan server Uvicorn NekoRimba di background thread Android."""
    try:
        if is_tv or os.environ.get("NEKORIMBA_IS_TV") == "1":
            os.environ["NEKORIMBA_IS_TV"] = "1"
            # Jangan override gc.set_threshold ke angka kecil karena memicu CPU thrashing & thermal throttling di TV Stick!

        base_dir = os.path.dirname(os.path.abspath(__file__))
        backend_dir = os.path.join(base_dir, "backend")
        frontend_dir = os.path.join(base_dir, "frontend")
        if backend_dir not in sys.path:
            sys.path.insert(0, backend_dir)

        if data_dir:
            os.environ["NEKORIMBA_DATABASE_PATH"] = os.path.join(data_dir, "anime.db")
            os.environ["NEKORIMBA_CACHE_DIR"] = os.path.join(data_dir, "cache")
            os.makedirs(data_dir, exist_ok=True)
            os.makedirs(os.path.join(data_dir, "cache"), exist_ok=True)

        os.environ["APP_HOST"] = "127.0.0.1"
        os.environ["APP_PORT"] = "8767"

        # Import main module setelah environment siap
        import main
        main.frontend_dir = frontend_dir

        import uvicorn
        print("[NEKORIMBA-SERVER] Menyalakan Uvicorn pada 127.0.0.1:8767...", flush=True)

        class AndroidServer(uvicorn.Server):
            def install_signal_handlers(self):
                # Pass karena dijalankan di secondary thread Android
                pass

        is_tv_mode = (os.environ.get("NEKORIMBA_IS_TV") == "1")
        config = uvicorn.Config(
            main.app,
            host="127.0.0.1",
            port=8767,
            loop="asyncio",
            http="h11",
            log_level="warning" if is_tv_mode else "info",
            access_log=False
        )
        server = AndroidServer(config=config)
        server.run()
    except Exception as e:
        import traceback
        print(f"[NEKORIMBA-SERVER-ERROR] {e}\n{traceback.format_exc()}", flush=True)

def run_in_background(data_dir=None, is_tv=False):
    t = threading.Thread(target=start_server, args=(data_dir, is_tv), daemon=True, name="NekoRimbaBackendThread")
    t.start()
    return True
