# Single source of truth version for NekoRimba backend
# Synchronized with root VERSION file by tools/bump_version.py

__version__ = "2.12.6"
