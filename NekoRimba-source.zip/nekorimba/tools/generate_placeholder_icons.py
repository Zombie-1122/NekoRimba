#!/usr/bin/env python3
"""Generate placeholder NekoRimba icons (cat-ear mark) for Android, TV banner, web and desktop.
Replace with your own artwork whenever you like: edit this script or overwrite the PNG/ICO files."""
import os
from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BG = (10, 13, 20, 255)
ACCENT = (255, 122, 182, 255)   # pink
ACCENT2 = (0, 219, 235, 255)    # cyan
SS = 4

def mark(size, transparent=False, scale=0.62):
    """Cat head with ears, on dark bg (or transparent)."""
    S = size * SS
    img = Image.new("RGBA", (S, S), (0, 0, 0, 0) if transparent else BG)
    d = ImageDraw.Draw(img)
    w = S * scale
    cx, cy = S / 2, S / 2 + S * 0.04
    r = w / 2 * 0.78                         # head radius
    # ears
    for sx in (-1, 1):
        d.polygon([(cx + sx * r * 0.95, cy - r * 0.15),
                   (cx + sx * r * 0.78, cy - r * 1.28),
                   (cx + sx * r * 0.18, cy - r * 0.78)], fill=ACCENT)
        d.polygon([(cx + sx * r * 0.80, cy - r * 0.38),
                   (cx + sx * r * 0.72, cy - r * 0.98),
                   (cx + sx * r * 0.36, cy - r * 0.72)], fill=BG if not transparent else (10, 13, 20, 255))
    # head
    d.ellipse([cx - r, cy - r * 0.85, cx + r, cy + r * 0.95], fill=ACCENT)
    # eyes
    for sx in (-1, 1):
        d.ellipse([cx + sx * r * 0.42 - r * 0.13, cy - r * 0.12 - r * 0.17,
                   cx + sx * r * 0.42 + r * 0.13, cy - r * 0.12 + r * 0.17], fill=(10, 13, 20, 255))
    # nose + whisker accents
    d.polygon([(cx - r * 0.08, cy + r * 0.28), (cx + r * 0.08, cy + r * 0.28), (cx, cy + r * 0.38)], fill=(10, 13, 20, 255))
    for sx in (-1, 1):
        for dy in (0.30, 0.46):
            d.line([(cx + sx * r * 0.45, cy + r * dy), (cx + sx * r * 1.05, cy + r * (dy - 0.06 + (dy - 0.38) * 0.6))],
                   fill=ACCENT2, width=max(2, int(S * 0.008)))
    return img.resize((size, size), Image.Resampling.LANCZOS)

def circle(img):
    s = img.size[0]
    m = Image.new("L", (s * SS, s * SS), 0)
    ImageDraw.Draw(m).ellipse([0, 0, s * SS - 1, s * SS - 1], fill=255)
    m = m.resize((s, s), Image.Resampling.LANCZOS)
    out = Image.new("RGBA", (s, s), (0, 0, 0, 0)); out.paste(img.convert("RGBA"), (0, 0), m); return out

def save(img, rel, mode=None):
    p = os.path.join(ROOT, rel); os.makedirs(os.path.dirname(p), exist_ok=True)
    (img.convert(mode) if mode else img).save(p); print("wrote", rel)

res = "android/app/src/main/res"
for folder, px in {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}.items():
    m = mark(px, scale=0.78)
    save(m, f"{res}/mipmap-{folder}/ic_launcher.png", "RGB")
    save(circle(m), f"{res}/mipmap-{folder}/ic_launcher_round.png")
save(mark(512, scale=0.78), f"{res}/drawable/ic_launcher.png", "RGB")
save(circle(mark(512, scale=0.78)), f"{res}/drawable/ic_launcher_round.png")
save(mark(432, transparent=True, scale=0.56), f"{res}/drawable/ic_launcher_foreground.png")

# TV banners
def banner(w, h):
    img = Image.new("RGBA", (w, h), BG)
    ic = mark(h, transparent=True, scale=0.62)
    img.alpha_composite(ic, (int(w * 0.12), 0))
    d = ImageDraw.Draw(img)
    try: font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", int(h * 0.2))
    except Exception: font = ImageFont.load_default()
    d.text((int(w * 0.12) + h * 0.95, h * 0.40), "NekoRimba", font=font, fill=(255, 255, 255, 255))
    return img
save(banner(640, 360), "android/app/src/tv/res/drawable-xhdpi/tv_banner.png")
save(banner(320, 180), "android/app/src/tv/res/drawable/tv_banner.png")

# web / desktop / assets
for rel, px in {"assets/nekorimba_icon_master.png": 1024, "assets/nekorimba_icon_512.png": 512,
                "frontend/assets/icon-512.png": 512, "frontend/assets/icon.png": 512,
                "frontend/assets/icon-192.png": 192}.items():
    save(mark(px, scale=0.78), rel, "RGB")
ico = mark(256, scale=0.78)
for rel in ("frontend/favicon.ico", "launcher/icon.ico", "launcher/winres/icon.ico"):
    p = os.path.join(ROOT, rel); ico.save(p, sizes=[(16, 16), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)]); print("wrote", rel)
